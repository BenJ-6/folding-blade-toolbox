<script setup lang="ts">
import Icon from "@/components/ui/Icon.vue";
import IconSprite from "@/components/ui/IconSprite.vue";

const checks = [
  "Tauri 2 + Vue 3 + TypeScript 脚手架",
  "Dialog / FS 插件与 capabilities 权限",
  "Vite 路径别名与 ESLint / Prettier",
  "设计变量与图标系统",
];
</script>

<template>
  <IconSprite />
  <main class="baseline">
    <section class="panel">
      <span class="stage">阶段 0 · 工程基线</span>
      <div class="mark"><Icon name="layers" :size="22" /></div>
      <h1>Toolbox 已就绪</h1>
      <p class="lead">工程配置搭建完成，图片压缩与尺寸调整界面将在下一阶段实现。</p>
      <ul class="checks">
        <li v-for="item in checks" :key="item">
          <span class="tick"><Icon name="check" :size="13" /></span>{{ item }}
        </li>
      </ul>
    </section>
  </main>
</template>

<style scoped>
.baseline {
  min-height: 100vh;
  display: grid;
  place-items: center;
  padding: 32px;
  background-image:
    radial-gradient(900px 420px at 88% -8%, rgba(99, 102, 241, 0.1), transparent 62%),
    radial-gradient(720px 380px at 4% 0%, rgba(139, 92, 246, 0.07), transparent 66%);
  background-repeat: no-repeat;
}

.panel {
  width: min(420px, 100%);
  padding: 30px 32px 28px;
  border: 1px solid var(--border);
  border-radius: 18px;
  background: var(--surface);
  box-shadow: var(--shadow-md);
}

.stage {
  display: inline-block;
  margin-bottom: 20px;
  padding: 4px 10px;
  border-radius: 999px;
  background: var(--accent-soft);
  color: var(--accent);
  font-size: 11.5px;
  font-weight: 600;
}

.mark {
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  margin-bottom: 14px;
  border-radius: 12px;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 10px 20px -10px rgba(99, 102, 241, 0.7);
}

h1 {
  margin-bottom: 6px;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: -0.02em;
}

.lead {
  margin-bottom: 20px;
  color: var(--text-3);
  font-size: 13px;
  line-height: 1.7;
}

.checks {
  display: flex;
  flex-direction: column;
  gap: 9px;
  margin: 0;
  padding: 16px 0 0;
  border-top: 1px solid var(--border);
  list-style: none;
  color: var(--text-2);
  font-size: 12.5px;
}

.checks li {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tick {
  width: 18px;
  height: 18px;
  display: grid;
  place-items: center;
  border-radius: 6px;
  background: var(--ok-soft);
  color: var(--ok);
}
</style>
