<script setup lang="ts">
withDefaults(defineProps<{ name: string; size?: number }>(), { size: 18 });
</script>

<template>
  <svg class="ui-icon" :width="size" :height="size" aria-hidden="true">
    <use :href="`#i-${name}`" />
  </svg>
</template>

<style scoped>
.ui-icon {
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
</style>
