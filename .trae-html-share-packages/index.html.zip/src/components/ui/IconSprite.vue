<template>
  <svg style="position: absolute; width: 0; height: 0; overflow: hidden" aria-hidden="true">
    <symbol id="i-layers" viewBox="0 0 24 24">
      <path d="M12 3.5l8.5 4.8L12 13.1 3.5 8.3 12 3.5z" />
      <path d="M3.5 12.2L12 17l8.5-4.8" />
      <path d="M3.5 16.1L12 20.9l8.5-4.8" />
    </symbol>
    <symbol id="i-image" viewBox="0 0 24 24">
      <rect x="3" y="3" width="18" height="18" rx="3.5" />
      <circle cx="8.6" cy="8.6" r="1.5" />
      <path d="M21 15.6l-4.4-4.4L7.6 20" />
    </symbol>
    <symbol id="i-zap" viewBox="0 0 24 24">
      <path d="M13 2L4.2 13.4h6.1L11 22l8.8-11.4h-6.1L13 2z" />
    </symbol>
    <symbol id="i-resize" viewBox="0 0 24 24">
      <path d="M20 4h-4.5M20 4v4.5M20 4l-6.5 6.5" />
      <path d="M4 20h4.5M4 20v-4.5M4 20l6.5-6.5" />
    </symbol>
    <symbol id="i-convert" viewBox="0 0 24 24">
      <path d="M4 8h11l-2.5-2.5M4 8l2.5 2.5" />
      <path d="M20 16H9l2.5 2.5M20 16l-2.5-2.5" />
    </symbol>
    <symbol id="i-rename" viewBox="0 0 24 24">
      <path d="M4 7h16M4 12h9M4 17h6" />
      <path d="M15 17h4.5v-4.5" />
    </symbol>
    <symbol id="i-pdf" viewBox="0 0 24 24">
      <rect x="4" y="3" width="16" height="18" rx="3" />
      <path d="M8 8h3M8 12h8M8 16h5" />
    </symbol>
    <symbol id="i-qr" viewBox="0 0 24 24">
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <path d="M13.5 13.5h3v3h-3zM20.5 13.5v3M13.5 20.5h3" />
    </symbol>
    <symbol id="i-palette" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="9" cy="9.2" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="15" cy="9.2" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="8.4" cy="14" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="13.6" cy="14.8" r="1.1" fill="currentColor" stroke="none" />
    </symbol>
    <symbol id="i-upload" viewBox="0 0 24 24">
      <path d="M12 16V4" />
      <path d="M7.5 8.5L12 4l4.5 4.5" />
      <path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" />
    </symbol>
    <symbol id="i-plus" viewBox="0 0 24 24">
      <path d="M12 5v14M5 12h14" />
    </symbol>
    <symbol id="i-x" viewBox="0 0 24 24">
      <path d="M18 6L6 18M6 6l12 12" />
    </symbol>
    <symbol id="i-download" viewBox="0 0 24 24">
      <path d="M12 4v11" />
      <path d="M7.5 11L12 15.5l4.5-4.5" />
      <path d="M4.5 19.5h15" />
    </symbol>
    <symbol id="i-lock" viewBox="0 0 24 24">
      <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" />
      <path d="M8.2 10.5V7.8a3.8 3.8 0 0 1 7.6 0v2.7" />
    </symbol>
    <symbol id="i-unlock" viewBox="0 0 24 24">
      <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" />
      <path d="M8.2 10.5V7.8a3.8 3.8 0 0 1 7.3-1.2" />
    </symbol>
    <symbol id="i-move" viewBox="0 0 24 24">
      <path d="M9 12H3M9 12l2.5-2.5M9 12l2.5 2.5" />
      <path d="M15 12h6M15 12l-2.5-2.5M15 12l2.5 2.5" />
    </symbol>
    <symbol id="i-check" viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5" />
    </symbol>
    <symbol id="i-sliders" viewBox="0 0 24 24">
      <path d="M4 7h6M14 7h6M4 12h10M18 12h2M4 17h3M11 17h9" />
      <circle cx="12" cy="7" r="2" />
      <circle cx="16" cy="12" r="2" />
      <circle cx="9" cy="17" r="2" />
    </symbol>
    <symbol id="i-loader" viewBox="0 0 24 24">
      <path d="M21 12a9 9 0 1 1-6.3-8.6" />
    </symbol>
  </svg>
</template>
